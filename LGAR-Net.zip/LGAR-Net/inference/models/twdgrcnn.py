import torch.nn as nn
import torch.nn.functional as F

from inference.models.grasp_model import GraspModel, DownSample,DepthwiseSeparableConv,CBAM,ResidualBlock,TDWConv


class GenerativeResnet(GraspModel):

    def __init__(self, input_channels=4, output_channels=1, channel_size=32, dropout=False, prob=0.0):
        super(GenerativeResnet, self).__init__()
        # self.conv1 = nn.Conv2d(input_channels, channel_size, kernel_size=9, stride=1, padding=4)
        # self.bn1 = nn.BatchNorm2d(channel_size)
        self.DWconv1 = DepthwiseSeparableConv(input_channels, channel_size, kernel_size=3, stride=1, padding=1)
        self.DownSample1 = DownSample()
        self.CBAM1=CBAM(channel=channel_size, reduction=16, kernel_size=7, padding=3)
        # self.conv2 = nn.Conv2d(channel_size, channel_size * 2, kernel_size=4, stride=2, padding=1)
        # self.bn2 = nn.BatchNorm2d(channel_size * 2)
        self.DWconv2 = DepthwiseSeparableConv(channel_size, channel_size*2, kernel_size=3, stride=1, padding=1)
        self.DownSample2 = DownSample()
        self.DWconv3 = DepthwiseSeparableConv(channel_size*2, channel_size*4, kernel_size=3, stride=1, padding=1)
        # self.conv3 = nn.Conv2d(channel_size * 2, channel_size * 4, kernel_size=4, stride=2, padding=1)
        # self.bn3 = nn.BatchNorm2d(channel_size * 4)

        self.res1 = ResidualBlock(channel_size * 4, channel_size * 4)
        self.res2 = ResidualBlock(channel_size * 4, channel_size * 4)
        self.res3 = ResidualBlock(channel_size * 4, channel_size * 4)
        self.res4 = ResidualBlock(channel_size * 4, channel_size * 4)
        self.res5 = ResidualBlock(channel_size * 4, channel_size * 4)
        self.TDWConv1 = TDWConv(in_channels=channel_size*4, out_channels=channel_size*2, kernel_size=3, stride=1, padding=1,scale_factor=2)
        self.TDWConv2 = TDWConv(in_channels=channel_size*2, out_channels=channel_size, kernel_size=3, stride=1, padding=1,scale_factor=2)
        self.CBAM2=CBAM(channel=channel_size, reduction=16, kernel_size=7, padding=3)
        self.TDWConv3 = TDWConv(in_channels=channel_size, out_channels=channel_size, kernel_size=3, stride=1, padding=1,scale_factor=1)
        # self.conv4 = nn.ConvTranspose2d(channel_size * 4, channel_size * 2, kernel_size=4, stride=2, padding=1,
        #                                 output_padding=1)
        # self.bn4 = nn.BatchNorm2d(channel_size * 2)

        # self.conv5 = nn.ConvTranspose2d(channel_size * 2, channel_size, kernel_size=4, stride=2, padding=2,
        #                                 output_padding=1)
        # self.bn5 = nn.BatchNorm2d(channel_size)

        # self.conv6 = nn.ConvTranspose2d(channel_size, channel_size, kernel_size=9, stride=1, padding=4)
        # self.pos_output = DepthwiseSeparableConv(channel_size, channel_size, kernel_size=3, stride=1, padding=1)
        # self.cos_output = DepthwiseSeparableConv(channel_size, channel_size, kernel_size=3, stride=1, padding=1)
        # self.sin_output = DepthwiseSeparableConv(channel_size, channel_size, kernel_size=3, stride=1, padding=1)
        # self.width_output = DepthwiseSeparableConv(channel_size, channel_size, kernel_size=3, stride=1, padding=1)
        self.pos_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.cos_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.sin_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.width_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)

        self.dropout = dropout
        self.dropout_pos = nn.Dropout(p=prob)
        self.dropout_cos = nn.Dropout(p=prob)
        self.dropout_sin = nn.Dropout(p=prob)
        self.dropout_wid = nn.Dropout(p=prob)

        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.xavier_uniform_(m.weight, gain=1)

    def forward(self, x_in):
        x1  = F.relu(self.DWconv1(x_in))
        x2  = self.CBAM1(x1)
        x3  = self.DownSample1(x2)
        x4  = F.relu(self.DWconv2(x3))
        x5  = self.DownSample2(x4)
        x6  = F.relu(self.DWconv3(x5))
        x7  = self.res1(x6)
        x8  = self.res2(x7)
        x9  = self.res3(x8)
        x10 = self.res4(x9)
        x11 = self.res5(x10)
        x12 = self.TDWConv1(x11)
        x13 = self.TDWConv2(x12)
        x14 = self.CBAM2(x13)
        x   = self.TDWConv3(x14)

        if self.dropout:
            pos_output = self.pos_output(self.dropout_pos(x))
            cos_output = self.cos_output(self.dropout_cos(x))
            sin_output = self.sin_output(self.dropout_sin(x))
            width_output = self.width_output(self.dropout_wid(x))
        else:
            pos_output = self.pos_output(x)
            cos_output = self.cos_output(x)
            sin_output = self.sin_output(x)
            width_output = self.width_output(x)

        return pos_output, cos_output, sin_output, width_output
