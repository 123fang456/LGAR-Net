import torch.nn as nn
import torch.nn.functional as F
import torch
####################################################################################################################################
#LOSS函数模块
#################################################################################################################################
class GraspModel(nn.Module):
    """
    An abstract model for grasp network in a common format.
    """

    def __init__(self):
        super(GraspModel, self).__init__()

    def forward(self, x_in):
        raise NotImplementedError()

    def compute_loss(self, xc, yc):
        i=0
        y_pos, y_cos, y_sin, y_width = yc
        if i==1:
            pos_pred, cos_pred, sin_pred, width_pred = self(xc)
        else :
            pos_pred, cos_pred, sin_pred, width_pred,loss_m = self(xc)
            loss_m = F.smooth_l1_loss(loss_m, y_pos)

        p_loss = F.smooth_l1_loss(pos_pred, y_pos)
        cos_loss = F.smooth_l1_loss(cos_pred, y_cos)
        sin_loss = F.smooth_l1_loss(sin_pred, y_sin)
        width_loss = F.smooth_l1_loss(width_pred, y_width)
        
        if i==1:
            return {
                'loss': p_loss + cos_loss + sin_loss + width_loss,
                'losses': {
                    'p_loss': p_loss,
                    'cos_loss': cos_loss,
                    'sin_loss': sin_loss,
                    'width_loss': width_loss,
                },
                'pred': {
                    'pos': pos_pred,
                    'cos': cos_pred,
                    'sin': sin_pred,
                    'width': width_pred
                }
            }
        else :
            return {
                'loss': p_loss + cos_loss + sin_loss + width_loss + loss_m,
                'losses': {
                    'p_loss': p_loss,
                    'cos_loss': cos_loss,
                    'sin_loss': sin_loss,
                    'width_loss': width_loss,
                    'loss_m': loss_m
                },
                'pred': {
                    'pos': pos_pred,
                    'cos': cos_pred,
                    'sin': sin_pred,
                    'width': width_pred
                }
            }
        

    def predict(self, xc):
        pos_pred, cos_pred, sin_pred, width_pred,loss_m = self(xc)
        return {
            'pos': pos_pred,
            'cos': cos_pred,
            'sin': sin_pred,
            'width': width_pred
        }

####################################################################################################################################
#残差模块（C+B+R+C+B）
#################################################################################################################################
class ResidualBlock(nn.Module):
    """
    A residual block with dropout option
    """

    def __init__(self, in_channels, out_channels, kernel_size=3):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size, padding=1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv2 = nn.Conv2d(in_channels, out_channels, kernel_size, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, x_in):
        x = self.bn1(self.conv1(x_in))
        x = F.relu(x)
        x = self.bn2(self.conv2(x))
        return x + x_in
    
####################################################################################################################################
#残差挤压激励模块 (（C+B+R+C+B）*(C+B+R  +C+S))R
#################################################################################################################################
class RSEModule(nn.Module): #RSE模块
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(RSEModule, self).__init__()
        
        self.residual = nn.Sequential(  #残差模块
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=kernel_size, padding=padding),
            nn.BatchNorm2d(out_channels)
        )
        
        self.squeeze = nn.Sequential(   #挤压模块
            nn.Conv2d(in_channels, out_channels // 4, kernel_size=1),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True)
        )
        
        self.excitation = nn.Sequential( #激励模块
            nn.Conv2d(out_channels // 4, out_channels, kernel_size=1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        residual = self.residual(x)
        squeeze = self.squeeze(x)
        excitation = self.excitation(squeeze)
        se_res = residual * excitation
        x = F.relu(se_res + x)
        return x
    
    
####################################################################################################################################
#上采样模块 Upsample
#################################################################################################################################    
class UpSample(nn.Module):#上采样层
    def __init__(self, scale_factor=2):
        super(UpSample, self).__init__()
        self.upsample = nn.Upsample(scale_factor=scale_factor, mode='bilinear', align_corners=True)
        
    def forward(self, x):
        x = self.upsample(x)
        return x
####################################################################################################################################
#多尺度空间金字塔模（无用）
#################################################################################################################################    
class SpatialPyramidPooling(nn.Module):
    def __init__(self, output_sizes=[4, 2, 1], input_channels=256):
        super(SpatialPyramidPooling, self).__init__()
        self.output_sizes = output_sizes
        self.input_channels = input_channels
        self.pool_layers = nn.ModuleList()
        for size in self.output_sizes:
            self.pool_layers.append(nn.AdaptiveMaxPool2d((size, size)))
            
    def forward(self, x):
        outputs = []
        for layer in self.pool_layers:
            out = layer(x)
            out = out.view(out.size(0), -1)
            outputs.append(out)
        return torch.cat(outputs, dim=1)
    
####################################################################################################################################
#残差挤压激励模块与多特征融合（无用）
#################################################################################################################################    
class ResidualSqueezeExcitationBlock(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(ResidualSqueezeExcitationBlock, self).__init__()
        self.residual_connection = nn.Identity()#恒等映射层:不做任何处理
        self.conv1 = nn.Conv2d(input_channels, output_channels, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(output_channels, output_channels, kernel_size=3, padding=1)
        self.squeeze_excitation = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(output_channels, output_channels // 16, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(output_channels // 16, output_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        identity = self.residual_connection(x)
        out = self.conv1(x)
        out = nn.functional.relu(out, inplace=True)
        out = self.conv2(out)
        out = self.squeeze_excitation(out) * out
        out += identity
        out = nn.functional.relu(out)
        return out

class MultiScaleSpatialPyramidModule(nn.Module):
    def __init__(self, input_channels, output_sizes=[4, 2, 1]):
        super(MultiScaleSpatialPyramidModule, self).__init__()
        self.output_sizes = output_sizes
        self.input_channels = input_channels
        self.pool_layers = nn.ModuleList()
        for size in self.output_sizes:
            self.pool_layers.append(nn.AdaptiveMaxPool2d((size, size)))
        self.conv = nn.Conv2d(input_channels * len(self.output_sizes), input_channels, kernel_size=1)

    def forward(self, x):
        outputs = []
        for layer in self.pool_layers:
            out = layer(x)
            out = out.view(out.size(0), -1)
            outputs.append(out)
        out = torch.cat(outputs, dim=1)
        out = self.conv(out[:, :, None, None].repeat(1, 1, x.size(2), x.size(3)))
        return out

class HierarchicalFeatureFusionNetwork(nn.Module):
    def __init__(self, num_res_se_blocks=5, input_channels=4, output_channels=32):
        super(HierarchicalFeatureFusionNetwork, self).__init__()
        self.num_res_se_blocks = num_res_se_blocks
        self.input_channels = input_channels
        self.output_channels = output_channels
        self.res_se_blocks = nn.ModuleList()
        for _ in range(num_res_se_blocks):
            self.res_se_blocks.append(ResidualSqueezeExcitationBlock(input_channels, output_channels))
        self.ms_spm = MultiScaleSpatialPyramidModule(output_channels)
        self.conv = nn.Conv2d(output_channels * (len(self.ms_spm.output_sizes) + 1), 
                              output_channels, kernel_size=1)
        
    def forward(self, x):
        outputs = []
        out = x
        for block in self.res_se_blocks:
            out = block(out)
            outputs.append(out)
        ms_spm_out = self.ms_spm(out)
        outputs.append(ms_spm_out)
        out = torch.cat(outputs, dim=1)
        out = self.conv(out[:, :, None, None].repeat(1, 1, x.size(2), x.size(3)))
        return out

####################################################################################################################################
#CBR模块
#################################################################################################################################
class Conv2d_ADD_BatchNorm2d(nn.Module):
    """
    A residual block with dropout option
    """
    def __init__(self, in_channels, out_channels, kernel_size=3):
        super(Conv2d_ADD_BatchNorm2d, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
    def forward(self, x_in):
        x = self.bn1(self.conv1(x_in))
        x = F.relu(x)
        return x
####################################################################################################################################
#MaxPool2d模块
################################################################################################################################# 
class DownSample(nn.Module):#下采样层
    def __init__(self):
        super(DownSample, self).__init__()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        
    def forward(self, x):
        x = self.pool(x)
        return x

####################################################################################################################################    
#并行卷积模块（无用）
#################################################################################################################################
class MultiScaleParallelDilatedConv_NOW(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1):
        super(MultiScaleParallelDilatedConv_NOW, self).__init__()
        # 定义四个并行卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=1)

        self.conv21 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=3, dilation=3)
        self.conv22 = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)

        self.conv31 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=1)
        self.conv32 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=3, dilation=3)
        self.conv33 = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)

        self.conv41 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=1)
        self.conv42 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=3, dilation=3)
        self.conv43 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=5, dilation=5)
        self.conv44 = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)

        # 定义一个池化层，用于将并行卷积层的输出进行池化融合
        #self.pool = nn.AdaptiveAvgPool2d(75)

    def forward(self, x):
        # 并行卷积计算
        x1 = self.conv1(x)
        x2 = self.conv22(self.conv21(x))
        x3 = self.conv33(self.conv32(self.conv31(x)))
        x4 = self.conv44(self.conv43(self.conv42(self.conv41(x))))
        # 使用 torch.stack() 函数将多个张量拼接成一个新的张量
        #tensor_list=[x1, x2, x3, x4]
        #stacked_tensor = torch.cat(tensor_list, dim=2)
        x=x1+x2+x3+x4+x
        x = F.relu(x)
        # 池化融合
        #out = torch.cat((self.pool(x1), self.pool(x2), self.pool(x3), self.pool(x4)), dim=1)
        return x
   
####################################################################################################################################    
#并行卷积模块（RSENMMSPM在用）
################################################################################################################################# 
class MultiScaleParallelDilatedConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1, dilation_rates=[1,3,5,7]):
        super(MultiScaleParallelDilatedConv, self).__init__()
        # 定义四个并行卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=1, dilation=dilation_rates[0])
        self.conv2 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=3, dilation=dilation_rates[1])
        self.conv3 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=5, dilation=dilation_rates[2])
        self.conv4 = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=7, dilation=dilation_rates[3])
        # 定义一个池化层，用于将并行卷积层的输出进行池化融合
        #self.pool = nn.AdaptiveAvgPool2d(75)

    def forward(self, x):
        # 并行卷积计算
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        x4 = self.conv4(x)
        # 使用 torch.stack() 函数将多个张量拼接成一个新的张量
        #tensor_list=[x1, x2, x3, x4]
        #stacked_tensor = torch.cat(tensor_list, dim=2)
        x=x1+x2+x3+x4
        x = F.relu(x)
        # 池化融合
        #out = torch.cat((self.pool(x1), self.pool(x2), self.pool(x3), self.pool(x4)), dim=1)
        return x

####################################################################################################################################   
#注意力模块
#################################################################################################################################
class ChannelAttentionModule(nn.Module):
    def __init__(self, channel, reduction=16):
        super(ChannelAttentionModule, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.max_pool = nn.AdaptiveMaxPool2d((1, 1))
        self.shared_MLP = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, kernel_size=1, stride=1, padding=0, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, kernel_size=1, stride=1, padding=0, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.shared_MLP(self.avg_pool(x))
        max_out = self.shared_MLP(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)

class SpatialAttentionModule(nn.Module):
    def __init__(self, kernel_size=7, padding=3):
        super(SpatialAttentionModule, self).__init__()
        self.conv2d = nn.Conv2d(in_channels=2, out_channels=1,
                                kernel_size=kernel_size, stride=1, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avg_out, max_out], dim=1)
        out = self.conv2d(out)
        return self.sigmoid(out)
    
class CBAM(nn.Module):
    def __init__(self, channel, reduction=16, kernel_size=7, padding=3):
        super(CBAM, self).__init__()
        self.channel_attention = ChannelAttentionModule(channel, reduction)
        self.spatial_attention = SpatialAttentionModule(kernel_size, padding)

    def forward(self, x):
        out = self.channel_attention(x) * x
        out = self.spatial_attention(out) * out
        return out
####################################################################################################################################
#SEGRCNN中的残差挤压激励模块(（C+B+R+C+B+AVGPOOL+C+R+C+S）*（C+B+R+C+B）)R 
#################################################################################################################################
class RESE(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(RESE, self).__init__()
        self.residual_connection = nn.Identity()#恒等映射层:不做任何处理
        self.residual1 = nn.Sequential(  #残差模块
            nn.Conv2d(input_channels, output_channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(output_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(output_channels, output_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(output_channels)
        )
        self.squeeze_excitation = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(output_channels, output_channels // 16, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(output_channels // 16, output_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        identity = self.residual_connection(x)
        out = self.residual1(x)
        out = self.squeeze_excitation(out) * out
        out += identity
        out = nn.functional.relu(out)
        return out



####################################################################################################################################
#深度可分离卷积模块
#################################################################################################################################
class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x
####################################################################################################################################
#反卷积模块
#双线性插值层：scale_factor ：倍数
#卷积层
#B+R层
#################################################################################################################################
class TDWConv(nn.Module):
    def __init__(self,in_channels, out_channels, kernel_size=3, stride=1, padding=1,scale_factor=2):
        super(TDWConv, self).__init__()
        self.scale_factor = scale_factor
        self.DSConv=nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size,stride=stride, padding=padding)
        self.bn1 = nn.BatchNorm2d(out_channels)

    def forward(self, input):
        output = F.interpolate(input, scale_factor=self.scale_factor, mode='bilinear', align_corners=True)
        output = self.DSConv(output)
        output = self.bn1(output)
        output = F.relu(output)
        return output
    
####################################################################################################################################
#双线性插值模块
#################################################################################################################################
class BilinearInterpolation(nn.Module):
    def __init__(self, scale_factor):
        super(BilinearInterpolation, self).__init__()
        self.scale_factor = scale_factor

    def forward(self, x):
        _, _, h, w = x.size()
        new_h = int(h * self.scale_factor)
        new_w = int(w * self.scale_factor)

        # 生成插值对应的坐标网格
        y = torch.linspace(0, h - 1, new_h).unsqueeze(1).expand(new_h, new_w)
        x = torch.linspace(0, w - 1, new_w).unsqueeze(0).expand(new_h, new_w)

        # 对应的坐标向左上方取整和向右下方取整
        y1 = torch.floor(y).long()
        x1 = torch.floor(x).long()
        y2 = y1 + 1
        x2 = x1 + 1

        # 将坐标限制在合理范围内
        y1 = torch.clamp(y1, 0, h - 1)
        y2 = torch.clamp(y2, 0, h - 1)
        x1 = torch.clamp(x1, 0, w - 1)
        x2 = torch.clamp(x2, 0, w - 1)

        # 获取四个角点像素的值
        Ia = x2.float().sub(x) * y2.float().sub(y)
        Ib = x2.float().sub(x) * y.sub(y1.float())
        Ic = x.sub(x1.float()) * y2.float().sub(y)
        Id = x.sub(x1.float()) * y.sub(y1.float())

        # 根据四个角点像素的值进行双线性插值
        output = (Ia.unsqueeze(0) * x[y1, x1] +
                  Ib.unsqueeze(0) * x[y2, x1] +
                  Ic.unsqueeze(0) * x[y1, x2] +
                  Id.unsqueeze(0) * x[y2, x2])

        return output