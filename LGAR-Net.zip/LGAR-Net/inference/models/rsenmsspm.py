import torch.nn as nn
import torch
import torch.nn.functional as F
import numpy as np

import matplotlib.pyplot as plt
import cv2
import os


from inference.models.grasp_model import GraspModel,Conv2d_ADD_BatchNorm2d,RSEModule,TDWConv,CBAM,ResidualBlock,DownSample
from utils.visualisation.save_feature import save_feature

class GenerativeResnet(GraspModel):

    def __init__(self, input_channels=4, output_channels=1, channel_size=32, dropout=False, prob=0.0):
        super(GenerativeResnet, self).__init__()
        self.conv2D1 = Conv2d_ADD_BatchNorm2d(input_channels, channel_size)
        self.conv2D2 = Conv2d_ADD_BatchNorm2d(channel_size, channel_size)
        self.conv2D3 = Conv2d_ADD_BatchNorm2d(channel_size, channel_size)
        self.conv2D4 = Conv2d_ADD_BatchNorm2d(channel_size, channel_size*2)
        self.down1 = DownSample()
        self.conv2D5 = Conv2d_ADD_BatchNorm2d(channel_size*2, channel_size*2)
        self.conv2D6 = Conv2d_ADD_BatchNorm2d(channel_size*2, channel_size*4)
        self.down2 = DownSample()
        self.res1 = RSEModule(channel_size * 4, channel_size * 4)
        self.res2 = RSEModule(channel_size * 4, channel_size * 4)
        self.res3 = RSEModule(channel_size * 4, channel_size * 4)
        self.res4 = RSEModule(channel_size * 4, channel_size * 4)
        self.res5 = RSEModule(channel_size * 4, channel_size * 4)
        self.res6 = RSEModule(channel_size * 4, channel_size * 4)
        self.lossconv=nn.Conv2d(channel_size*4, 1, kernel_size=1,stride=1, padding=0)
        self.CBAM1=CBAM(channel=channel_size*4)
        self.conv2D=nn.Conv2d(in_channels=channel_size*28, out_channels=channel_size*4, kernel_size=3, padding=1)

        self.TDWConv1 = TDWConv(in_channels=channel_size*4, out_channels=channel_size*2, kernel_size=3, stride=1, padding=1,scale_factor=2)
        self.TDWConv2 = TDWConv(in_channels=channel_size*2, out_channels=channel_size, kernel_size=3, stride=1, padding=1,scale_factor=2)

        self.pos_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.cos_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.sin_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)
        self.width_output = nn.Conv2d(in_channels=channel_size, out_channels=output_channels, kernel_size=3, padding=1)

        self.dropout = dropout
        self.dropout_pos = nn.Dropout(p=prob)
        self.dropout_cos = nn.Dropout(p=prob)
        self.dropout_sin = nn.Dropout(p=prob)
        self.dropout_wid = nn.Dropout(p=prob)

        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.xavier_uniform_(m.weight, gain=1)

    def forward(self, x_in):
        i=0
        x = self.conv2D1(x_in) #2*32*300*300
        x = self.conv2D2(x)
        x = self.conv2D3(x)
        x = self.conv2D4(x)
        x = self.down1(x)     #2*64*150*150
        x = self.conv2D5(x)
        x = self.conv2D6(x)
        x = self.down2(x)    #2*128*75*75
        x1 = self.res1(x)
        x2 = self.res2(x1)
        x3 = self.res3(x2)
        x4 = self.res4(x3)
        x5 = self.res5(x4)
        x6 = self.res6(x5)
        # if i==1:
        #     save_feature(x6,19)
        x7 = self.lossconv(x6) #2*1*75*75
        loss_m = F.interpolate(x7, scale_factor=4, mode='bilinear', align_corners=True)
        # if i==1:
        #     save_feature(loss_m,20)
        x8 = self.CBAM1(x6*x7)
        feats = [x1, x2, x3, x4,x5, x6, x8]
        # 按照通道维度进行拼接，得到大小为(batch_size, 7 * 128, 75,75 )的张量
        concat_feat = torch.cat(feats, dim=1)
        x = self.conv2D(concat_feat)  #2*256*75*75
        # if i==1:
        #     save_feature(x,21)
        x = self.TDWConv1(x)    #2*128*150*150
        x = self.TDWConv2(x)   #2*64*300*300
        save_feature(x,10)
        # if i==1:
        #     save_feature(x,22)
        if self.dropout:
            pos_output = self.pos_output(self.dropout_pos(x))
            if i==1:
                save_feature(pos_output,23)
            cos_output = self.cos_output(self.dropout_cos(x))
            if i==1:
                save_feature(cos_output,24)
            sin_output = self.sin_output(self.dropout_sin(x))
            if i==1:
                save_feature(sin_output,25)
            width_output = self.width_output(self.dropout_wid(x))
            if i==1:
                save_feature(width_output,26)
        else:
            pos_output = self.pos_output(x)
            cos_output = self.cos_output(x)
            sin_output = self.sin_output(x)
            width_output = self.width_output(x)

        return pos_output, cos_output, sin_output, width_output,loss_m
