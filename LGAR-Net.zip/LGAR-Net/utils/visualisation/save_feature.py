import matplotlib.pyplot as plt
import cv2
import os

def save_feature(x,layers):
    save_dir = "F:/桌面文件夹/feature"  # 设置保存目录
    for i in range(x.shape[1]):
        # 获取第i个特征图    G:\桌面文件夹\网络特征图
        # 绘制热力图
        plt.imshow(x[0, i], cmap='jet', alpha=0.5,extent=[0, 300, 0, 300])
        plt.axis('off')
        # 生成文件名
        filename = f"feature_{i}.png"
        foldername = f"network_layers_{layers}"
        if layers > 22:
            foldername = f"network_layers_23"
            filename = f"feature_{layers}.png"
        folder_path = os.path.join(os.path.dirname(save_dir), foldername)  # 上一级路径 + 文件夹名
        filepath = os.path.join(folder_path, filename)  # 完整的文件路径
        # 创建上一级文件夹（如果不存在）
        os.makedirs(folder_path, exist_ok=True)
        # 保存图像
        plt.savefig(filepath)
        plt.close()