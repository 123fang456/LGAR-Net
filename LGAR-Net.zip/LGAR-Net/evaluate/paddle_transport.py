from x2paddle.convert import pytorch2paddle
import torch
import numpy as np

# 构建输入
input_data = np.random.rand(1, 3, 224, 224).astype("float32")
if __name__ == '__main__':
    pytorch2paddle(module="trained-models/jacquard-rgbd-grconvnet3-drop0-ch32/epoch_35_iou_0.92",
               save_dir="./pd_model",
               jit_type="trace",
               input_examples=[torch.tensor(input_data)])
# module (torch.nn.Module): PyTorch的Module。
# save_dir (str): 转换后模型的保存路径。
# jit_type (str): 转换方式。默认为"trace"。
# input_examples (list[torch.tensor]): torch.nn.Module的输入示例，list的长度必须与输入的长度一致。默认为None。