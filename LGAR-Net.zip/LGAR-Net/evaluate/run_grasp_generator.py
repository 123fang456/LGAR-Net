from inference.grasp_generator import GraspGenerator

if __name__ == '__main__':
    generator = GraspGenerator(
        cam_id=830112070066,
        saved_model_path='G:\桌面文件夹\4.研一科研课程\6.ros+深度学习神经网络在Ubuntu运行项目文件\3.GRCNN网络\GRCNN\logs\230402_0923_\epoch_08_iou_0.83',
        visualize=True
    )
    generator.load_model()
    generator.run()
