import torch
import torchvision.models as models
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt

from inference.post_process import post_process_output
from utils.data.camera_data import CameraData
from utils.dataset_processing.grasp import detect_grasps
from utils.visualisation.plot import plot_grasp,save_results
import cv2
from PIL import Image
import torchvision.transforms as transforms


class PlaneGraspClass:
    def __init__(self, saved_model_path=None,use_cuda=False,visualize=False,include_rgb=True,include_depth=False,output_size=300):
        if saved_model_path==None:
            saved_model_path = 'resmssp_results/c_0/v3.0.2/epoch_23_iou_0.89.pth'
        self.model = torch.load(saved_model_path, map_location=torch.device('cpu'))
        self.device = "cuda:0" if use_cuda else "cpu"
        self.visualize = visualize

        self.cam_data = CameraData(include_rgb=include_rgb,include_depth=include_depth,output_size=output_size)

        if self.visualize:
            self.fig = plt.figure(figsize=(6, 6))
        else:
            self.fig = None

    def generate(self):
        rgb = cv2.imread("./c5.png")
        cv2.imwrite("test.png", rgb)
        rgb_path = "./test.png"
        #rgb_path = "./c5.png"
        rgb = np.array(Image.open(rgb_path))
        x, depth_img,rgb_img = self.cam_data.get_data(rgb=rgb)
        rgb = cv2.cvtColor(rgb,cv2.COLOR_BGR2RGB)

        with torch.no_grad():
            xc = x.to(self.device)
            pred = self.model.predict(xc)
        q_img, ang_img, width_img = post_process_output(pred['pos'], pred['cos'], pred['sin'], pred['width'])
        grasps = detect_grasps(q_img, ang_img, width_img)
        if len(grasps) ==0:
            print("Detect 0 grasp pose!")
            if self.visualize:
                plot_grasp(fig=self.fig, rgb_img=self.cam_data.get_rgb(rgb, False), grasps=grasps, save=True)
            return False
        if self.visualize:
            #plot_grasp(fig=self.fig, rgb_img=self.cam_data.get_rgb(rgb, False), grasps=grasps, save=True)
            save_results(rgb_img=self.cam_data.get_rgb(rgb, False),grasp_q_img=q_img,grasp_angle_img=ang_img,grasp_width_img=width_img)
        return True


if __name__ == '__main__':
    g = PlaneGraspClass(
        #saved_model_path='logs/230402_0923_/epoch_08_iou_0.83', #grcnn的rgb模型
        #saved_model_path='resmssp_results/epoch_19_iou_0.98.pth',#rsenmssp的rgbd模型
        #saved_model_path='resmssp_results/j_0/epoch_07_iou_0.74.pth',#rsenmssp的rgb模型
        #saved_model_path='resmssp_results/j_0/v2.0.3/epoch_00_iou_0.67.pth',#rsenmsspv2的rgb模型
        #saved_model_path='resmssp_results/c_0/v3.0.2/epoch_19_iou_0.89.pth',#rsenmsspv2的rgb模型
        #saved_model_path='trained-models/cornell-randsplit-rgbd-grconvnet3-drop1-ch16/epoch_30_iou_0.97',
        visualize=True,
        include_rgb=True
    )
    g.generate()
