import argparse
import datetime
import json
import logging
import os
import sys
import torchvision
import matplotlib.pyplot as plt

import cv2
import numpy as np
import tensorboardX
import torch
import torch.optim as optim
import torch.utils.data
from torchsummary import summary

from hardware.device import get_device
from inference.models import get_network
from inference.post_process import post_process_output
from utils.data import get_dataset
from utils.dataset_processing import evaluation
from utils.visualisation.gridshow import gridshow


def parse_args():
    parser = argparse.ArgumentParser(description='Train network')

    # Network
    parser.add_argument('--network', type=str, default='ggcnn',
                        help='Network name in inference/models')
    parser.add_argument('--input-size', type=int, default=300,
                        help='Input image size for the network')
    parser.add_argument('--use-depth', type=int, default=0,
                        help='Use Depth image for training (1/0)')
    parser.add_argument('--use-rgb', type=int, default=1,
                        help='Use RGB image for training (1/0)')
    parser.add_argument('--use-dropout', type=int, default=1,
                        help='Use dropout for training (1/0)')
    parser.add_argument('--dropout-prob', type=float, default=0.1,
                        help='Dropout prob for training (0-1)')
    parser.add_argument('--channel-size', type=int, default=32,
                        help='Internal channel size for the network')
    parser.add_argument('--iou-threshold', type=float, default=0.25,
                        help='Threshold for IOU matching')

    # Datasets
    parser.add_argument('--dataset', type=str, default="cornell",
                        help='Dataset Name ("cornell" or "jacquard")')
    parser.add_argument('--dataset-path', type=str, default="F:\桌面文件夹\cornell",
                        help='Path to dataset')
    parser.add_argument('--split', type=float, default=0.8,
                        help='Fraction of data for training (remainder is validation)')
    parser.add_argument('--ds-shuffle', action='store_true', default=False,
                        help='Shuffle the dataset')
    parser.add_argument('--ds-rotate', type=float, default=0.0,
                        help='Shift the start point of the dataset to use a different test/train split')
    parser.add_argument('--num-workers', type=int, default=8,
                        help='Dataset workers')

    # Training
    parser.add_argument('--batch-size', type=int, default=8,#每次输入样本数：8，即8个rgb图像
                        help='Batch size')
    parser.add_argument('--epochs', type=int, default=50,#训练过程中数据集被使用的次数
                        help='Training epochs')
    parser.add_argument('--batches-per-epoch', type=int, default=1000,#每个 epoch 中处理多少个批次数据
                        help='Batches per Epoch')
    parser.add_argument('--optim', type=str, default='adam',#Adam 优化算法，一种自适应学习率的优化算法，具有较快的收敛速度和较好的性能表现
                        help='Optmizer for the training. (adam or SGD)')

    # Logging etc.
    parser.add_argument('--description', type=str, default='',
                        help='Training description')
    parser.add_argument('--logdir', type=str, default='logs/',
                        help='Log directory')
    parser.add_argument('--vis', action='store_true',
                        help='Visualise the training process')
    parser.add_argument('--cpu', dest='force_cpu', action='store_true', default=False,
                        help='Force code to run in CPU mode')
    parser.add_argument('--random-seed', type=int, default=123,
                        help='Random seed for numpy')

    args = parser.parse_args()
    return args


def validate(net, device, val_data, iou_threshold):
    """
    Run validation.
    :param net: Network
    :param device: Torch device
    :param val_data: Validation Dataset
    :param iou_threshold: IoU threshold
    :return: Successes, Failures and Losses
    """
    net.eval()

    results = {
        'correct': 0,
        'failed': 0,
        'loss': 0,
        'losses': {

        }
    }

    ld = len(val_data)

    with torch.no_grad():
        for x, y, didx, rot, zoom_factor in val_data:
            xc = x.to(device)
            yc = [yy.to(device) for yy in y]
            lossd = net.compute_loss(xc, yc)

            loss = lossd['loss']

            results['loss'] += loss.item() / ld
            for ln, l in lossd['losses'].items():
                if ln not in results['losses']:
                    results['losses'][ln] = 0
                results['losses'][ln] += l.item() / ld

            q_out, ang_out, w_out = post_process_output(lossd['pred']['pos'], lossd['pred']['cos'],
                                                        lossd['pred']['sin'], lossd['pred']['width'])
            # print(q_out.shape)

            s = evaluation.calculate_iou_match(q_out,
                                               ang_out,
                                               val_data.dataset.get_gtbb(didx, rot, zoom_factor),
                                               no_grasps=1,
                                               grasp_width=w_out,
                                               threshold=iou_threshold
                                               )

            if s:
                results['correct'] += 1
            else:
                results['failed'] += 1

    return results

#train_data有18656个数据
def train(epoch, net, device, train_data, optimizer, batches_per_epoch, vis=False):
    """
    Run one training epoch
    :param epoch: Current epoch
    :param net: Network
    :param device: Torch device
    :param train_data: Training Dataset
    :param optimizer: Optimizer
    :param batches_per_epoch:  Data batches to train on
    :param vis:  Visualise training progress
    :return:  Average Losses for Epoch
    """
    results = {
        'loss': 0,
        'losses': {
        }
    }

    net.train()

    batch_idx = 0
    #batches_per_epoch：每个 epoch 中处理多少个批次数据
    # Use batches per epoch to make training on different sized datasets (cornell/jacquard) more equivalent.
    while batch_idx <= batches_per_epoch:
        for x, y, _, _, _ in train_data: 
            #x 是一个8*3*300*300 的张量； y是列表 列表有4个数据（质量、宽度、cos、sin） 每个数据里面有8*1*300*300 的标签
            batch_idx += 1
            if batch_idx >= batches_per_epoch:
                break
            xc = x.to(device)
            #xc 是8*3*300*300 的张量；
            yc = [yy.to(device) for yy in y]
            lossd = net.compute_loss(xc, yc)
            # # 将所有张量拼接在一起
            # grid = torchvision.utils.make_grid(yc[0], nrow=4)
            # # 使用pyplot.imshow将张量以图片方式展示出来
            # plt.imshow(grid.permute(1, 2, 0))
            # plt.axis('off')
            # plt.show()
            loss = lossd['loss']

            if batch_idx % 100 == 0:
                logging.info('Epoch: {}, Batch: {}, Loss: {:0.4f}'.format(epoch, batch_idx, loss.item()))

            results['loss'] += loss.item()
            for ln, l in lossd['losses'].items():
                if ln not in results['losses']:
                    results['losses'][ln] = 0
                results['losses'][ln] += l.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # Display the images
            if vis:
                imgs = []
                n_img = min(4, x.shape[0])
                for idx in range(n_img):
                    imgs.extend([x[idx,].numpy().squeeze()] + [yi[idx,].numpy().squeeze() for yi in y] + [
                        x[idx,].numpy().squeeze()] + [pc[idx,].detach().cpu().numpy().squeeze() for pc in
                                                      lossd['pred'].values()])
                gridshow('Display', imgs,
                         [(xc.min().item(), xc.max().item()), (0.0, 1.0), (0.0, 1.0), (-1.0, 1.0),
                          (0.0, 1.0)] * 2 * n_img,
                         [cv2.COLORMAP_BONE] * 10 * n_img, 10)
                cv2.waitKey(2)

    results['loss'] /= batch_idx
    for l in results['losses']:
        results['losses'][l] /= batch_idx

    return results


def run():
    args = parse_args()

    # Set-up output directories
    dt = datetime.datetime.now().strftime('%y%m%d_%H%M')#使用了Python内置的datetime模块获取当前的日期和时间，并将其格式化为一个字符串，格式230402_0930
    net_desc = '{}_{}_{}'.format(dt,''.join(args.network),''.join(args.dataset))#使用 Python 字符串的format()方法创建了一个字符串 net_desc

    save_folder = os.path.join(args.logdir, net_desc)#将 args.logdir 和 net_desc 两个字符串参数连接在一起，形成一个新的字符串，表示保存神经网络模型和日志文件的路径
    if not os.path.exists(save_folder):#将神经网络训练时的损失值和其他统计信息保存到 TensorBoard 事件文件中
        os.makedirs(save_folder)
    tb = tensorboardX.SummaryWriter(save_folder)

    # Save commandline args
    if args is not None:#保存程序运行时的命令行参数，以便于后续查询和重复执行
        params_path = os.path.join(save_folder, 'commandline_args.json')
        with open(params_path, 'w') as f:
            json.dump(vars(args), f)

    # Initialize logging
    logging.root.handlers = []
    logging.basicConfig(
        level=logging.INFO,
        filename="{0}/{1}.log".format(save_folder, 'log'),
        format='[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    # set up logging to console 输出到控制台
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use 设置输出到控制台的显示格式
    formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    console.setFormatter(formatter)
    # add the handler to the root logger 把这个句柄添加到根logger中
    logging.getLogger('').addHandler(console)

    # Get the compute device 设置处理器设备
    device = torch.device('cpu')

    # Load Dataset 载入数据
    logging.info('Loading {} Dataset...'.format(args.dataset.title()))
    Dataset = get_dataset(args.dataset)#创建数据集类
    #实例化数据集类
    dataset = Dataset(args.dataset_path,#指定数据集文件夹的根目录
                      output_size=args.input_size,#指定输出图像的大小
                      ds_rotate=args.ds_rotate,#指定是否对数据集进行旋转操作
                      random_rotate=True,#指定是否对输入图像进行随机旋转操作
                      random_zoom=True,#指定是否对输入图像进行随机缩放操作
                      include_depth=args.use_depth,
                      include_rgb=args.use_rgb)
    logging.info('Dataset size is {}'.format(dataset.length))

    # Creating data indices for training and validation splits 为数据集划分训练集和验证集
    indices = list(range(dataset.length))
    split = int(np.floor(args.split * dataset.length))
    if args.ds_shuffle: #对数据集进行随机打乱
        np.random.seed(args.random_seed)
        np.random.shuffle(indices)
    train_indices, val_indices = indices[:split], indices[split:]
    logging.info('Training size: {}'.format(len(train_indices)))
    logging.info('Validation size: {}'.format(len(val_indices)))

    # Creating data samplers and loaders 创建 PyTorch 中的数据采样器 并用这些采样器创建数据加载器
    train_sampler = torch.utils.data.sampler.SubsetRandomSampler(train_indices)
    val_sampler = torch.utils.data.sampler.SubsetRandomSampler(val_indices)

    train_data = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        sampler=train_sampler
    )
    val_data = torch.utils.data.DataLoader(
        dataset,
        batch_size=1,
        num_workers=args.num_workers,
        sampler=val_sampler
    )
    logging.info('Done')

    #################################
    # 将模型的参数分为前部分和后部分
    fixed_params = ['conv2D1.conv1.weight',
                     'conv2D1.conv1.bias',
                     'conv2D1.bn1.weight',
                     'conv2D1.bn1.bias',
                     'conv2D2.conv1.weight',
                     'conv2D2.conv1.bias',
                     'conv2D2.bn1.weight',
                     'conv2D2.bn1.bias',
                     'conv2D4.conv1.weight',
                     'conv2D4.conv1.bias',
                     'conv2D4.bn1.weight',
                     'conv2D4.bn1.bias',
                     'conv2D6.conv1.weight',
                     'conv2D6.conv1.bias',
                     'conv2D6.bn1.weight',
                     'conv2D6.bn1.bias',
                     'RSEM1.residual.0.weight',
                     'RSEM1.residual.0.bias',
                     'RSEM1.residual.1.weight',
                     'RSEM1.residual.1.bias',
                     'RSEM1.residual.3.weight',
                     'RSEM1.residual.3.bias',
                     'RSEM1.residual.4.weight',
                     'RSEM1.residual.4.bias',
                     'RSEM1.squeeze.0.weight',
                     'RSEM1.squeeze.0.bias',
                     'RSEM1.squeeze.1.weight',
                     'RSEM1.squeeze.1.bias',
                     'RSEM1.excitation.0.weight',
                     'RSEM1.excitation.0.bias',
                     'RSEM2.residual.0.weight',
                     'RSEM2.residual.0.bias',
                     'RSEM2.residual.1.weight',
                     'RSEM2.residual.1.bias',
                     'RSEM2.residual.3.weight',
                     'RSEM2.residual.3.bias',
                     'RSEM2.residual.4.weight',
                     'RSEM2.residual.4.bias',
                     'RSEM2.squeeze.0.weight',
                     'RSEM2.squeeze.0.bias',
                     'RSEM2.squeeze.1.weight',
                     'RSEM2.squeeze.1.bias',
                     'RSEM2.excitation.0.weight',
                     'RSEM2.excitation.0.bias',
                     'RSEM3.residual.0.weight',
                     'RSEM3.residual.0.bias',
                     'RSEM3.residual.1.weight',
                     'RSEM3.residual.1.bias',
                     'RSEM3.residual.3.weight',
                     'RSEM3.residual.3.bias',
                     'RSEM3.residual.4.weight',
                     'RSEM3.residual.4.bias',
                     'RSEM3.squeeze.0.weight',
                     'RSEM3.squeeze.0.bias',
                     'RSEM3.squeeze.1.weight',
                     'RSEM3.squeeze.1.bias',
                     'RSEM3.excitation.0.weight',
                     'RSEM3.excitation.0.bias',
                     'RSEM4.residual.0.weight',
                     'RSEM4.residual.0.bias',
                     'RSEM4.residual.1.weight',
                     'RSEM4.residual.1.bias',
                     'RSEM4.residual.3.weight',
                     'RSEM4.residual.3.bias',
                     'RSEM4.residual.4.weight',
                     'RSEM4.residual.4.bias',
                     'RSEM4.squeeze.0.weight',
                     'RSEM4.squeeze.0.bias',
                     'RSEM4.squeeze.1.weight',
                     'RSEM4.squeeze.1.bias',
                     'RSEM4.excitation.0.weight',
                     'RSEM4.excitation.0.bias',
                     'RSEM5.residual.0.weight',
                     'RSEM5.residual.0.bias',
                     'RSEM5.residual.1.weight',
                     'RSEM5.residual.1.bias',
                     'RSEM5.residual.3.weight',
                     'RSEM5.residual.3.bias',
                     'RSEM5.residual.4.weight',
                     'RSEM5.residual.4.bias',
                     'RSEM5.squeeze.0.weight',
                     'RSEM5.squeeze.0.bias',
                     'RSEM5.squeeze.1.weight',
                     'RSEM5.squeeze.1.bias',
                     'RSEM5.excitation.0.weight',
                     'RSEM5.excitation.0.bias',
                     'RSEM6.residual.0.weight',
                     'RSEM6.residual.0.bias',
                     'RSEM6.residual.1.weight',
                     'RSEM6.residual.1.bias',
                     'RSEM6.residual.3.weight',
                     'RSEM6.residual.3.bias',
                     'RSEM6.residual.4.weight',
                     'RSEM6.residual.4.bias',
                     'RSEM6.squeeze.0.weight',
                     'RSEM6.squeeze.0.bias',
                     'RSEM6.squeeze.1.weight',
                     'RSEM6.squeeze.1.bias',
                     'RSEM6.excitation.0.weight',
                     'RSEM6.excitation.0.bias',
                     'RSEM7.residual.0.weight',
                     'RSEM7.residual.0.bias',
                     'RSEM7.residual.1.weight',
                     'RSEM7.residual.1.bias',
                     'RSEM7.residual.3.weight',
                     'RSEM7.residual.3.bias',
                     'RSEM7.residual.4.weight',
                     'RSEM7.residual.4.bias',
                     'RSEM7.squeeze.0.weight',
                     'RSEM7.squeeze.0.bias',
                     'RSEM7.squeeze.1.weight',
                     'RSEM7.squeeze.1.bias',
                     'RSEM7.excitation.0.weight',
                     'RSEM7.excitation.0.bias',
                     'conv2D.weight',
                     'conv2D.bias',
                     'TDWConv1.DSConv.weight',
                     'TDWConv1.DSConv.bias',
                     'TDWConv1.bn1.weight',
                     'TDWConv1.bn1.bias',
                     'TDWConv2.DSConv.weight',
                     'TDWConv2.DSConv.bias',
                     'TDWConv2.bn1.weight',
                     'TDWConv2.bn1.bias',
                     'TDWConv3.DSConv.weight',
                     'TDWConv3.DSConv.bias',
                     'TDWConv3.bn1.weight',
                     'TDWConv3.bn1.bias']  # 前部分参数的名称或层的名称
    train_params = ['pos_output.weight',
                     'pos_output.bias',
                     'cos_output.weight',
                     'cos_output.bias',
                     'sin_output.weight',
                     'sin_output.bias',
                     'width_output.weight',
                     'width_output.bias']  # 后部分参数的名称或层的名称
    ###################################

    # Load the network 加载定义好的神经网络，并初始化网络的参数
    logging.info('Loading Network...')
    input_channels = 1 * args.use_depth + 3 * args.use_rgb
    
    #net = torch.load('resmssp_results/c_0/v2.0.3/epoch_35_iou_0.93.pth', map_location=torch.device('cpu'))

    network = get_network(args.network)
    net = network(
        input_channels=input_channels,
        dropout=args.use_dropout,
        prob=args.dropout_prob,
        channel_size=args.channel_size
    )

    # 冻结前部分参数 resmssp_results/c_0/v2.0.3/epoch_35_iou_0.93.pth
    # for name, param in net.named_parameters():
    #     if any(layer in name for layer in fixed_params):
    #         param.requires_grad = False
    #     if any(layer in name for layer in train_params):
    #         param.requires_grad = True
    #确认参数的修改
    # for name, param in net.named_parameters():
    #     print(name, param.requires_grad)
    # for name, param in net.named_parameters():
    #     print(name, param.size())


    net = net.to(device)
    logging.info('Done')

    if args.optim.lower() == 'adam':
        optimizer = optim.Adam(filter(lambda p: p.requires_grad, net.parameters()), lr=0.001) #filter(lambda p: p.requires_grad, net.parameters()), lr=0.001
    elif args.optim.lower() == 'sgd':
        optimizer = optim.SGD(net.parameters(), lr=0.01, momentum=0.9)
    else:
        raise NotImplementedError('Optimizer {} is not implemented'.format(args.optim))

    # Print model architecture.输出神经网络的结构，包括每层的名称、输入/输出形状、参数数量等，并将输出结果写入文件中
    summary(net, (input_channels, args.input_size, args.input_size))
    f = open(os.path.join(save_folder, 'arch.txt'), 'w')
    sys.stdout = f
    summary(net, (input_channels, args.input_size, args.input_size))
    sys.stdout = sys.__stdout__
    f.close()

    best_iou = 0.0#初始化最佳交并比（IoU）指标值
    for epoch in range(args.epochs):#循环使用训练集
        logging.info('Beginning Epoch {:02d}'.format(epoch))
        train_results = train(epoch, net, device, train_data, optimizer, args.batches_per_epoch, vis=args.vis)

        # Log training losses to tensorboard
        tb.add_scalar('loss/train_loss', train_results['loss'], epoch)
        for n, l in train_results['losses'].items():
            tb.add_scalar('train_loss/' + n, l, epoch)

        # Run Validation
        logging.info('Validating...')
        test_results = validate(net, device, val_data, args.iou_threshold)
        logging.info('%d/%d = %f' % (test_results['correct'], test_results['correct'] + test_results['failed'],
                                     test_results['correct'] / (test_results['correct'] + test_results['failed'])))

        # Log validation results to tensorbaord
        tb.add_scalar('loss/IOU', test_results['correct'] / (test_results['correct'] + test_results['failed']), epoch)
        tb.add_scalar('loss/val_loss', test_results['loss'], epoch)
        for n, l in test_results['losses'].items():
            tb.add_scalar('val_loss/' + n, l, epoch)
        # Save best performing network
        iou = test_results['correct'] / (test_results['correct'] + test_results['failed'])
        if iou > best_iou or epoch == 0 or (epoch % 10) == 0:
            torch.save(net, os.path.join(save_folder, 'epoch_%02d_iou_%0.2f.pth' % (epoch, iou)))
            best_iou = iou


if __name__ == '__main__':
    run()
