import numpy as np
# import matplotlib.pyplot as plt

# # 创建一个线条型的一维数组
# array = np.array([0, 0.14, 0.36, 0.51, 0.71, 0.84, 1.06, 1.20, 1.38,1.53, 1.74, 1.86, 2.06, 2.21, 2.39, 2.52, 2.73, 2.85,3.04,3.17,3.36,3.48,3.69,3.81,3.99,4.13,4.31,4.43,4.61,4.74,4.90,5.02,5.22,5.33,5.51,5.63,5.81,5.91,6.11,6.23,6.40,6.52,6.70,6.82,7.00,7.12,7.30,7.42,7.61,7.72,7.90,8.02,8.16,8.31,8.49,8.62,8.79,8.91,9.10,9.22,9.43,9.56,9.75,9.89,10.10])

# # 设置X轴的坐标值
# x = np.arange(len(array)) * 10

# # 绘制线条型的一维数组
# plt.plot(x, array)

# # 设置图形标题和轴标签
# plt.title("Line Plot of 1D Array with X Spacing of 10")
# plt.xlabel("X")
# plt.ylabel("Value")

# # 显示图形
# plt.show()


#####################################################################################
# import cv2

# def canny_edge_detection(image):
#     # 转换为灰度图像
#     gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
#     # 使用高斯滤波平滑图像
#     blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
#     # 计算图像梯度
#     gradient_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=5)
#     gradient_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=5)
    
#     # 计算梯度的幅值和方向
#     gradient_magnitude = cv2.magnitude(gradient_x, gradient_y)
#     gradient_angle = cv2.phase(gradient_x, gradient_y, angleInDegrees=True)
    
#     # 应用非最大抑制，细化边缘
#     suppressed = cv2.Canny(blurred, 50, 150)
    
#     # 输出结果
#     return suppressed

# # 加载图像
# image = cv2.imread('1111.png')

# # 使用 Canny 算子进行边缘检测
# edges = canny_edge_detection(image)

# # 显示原始图像和边缘检测结果
# cv2.imshow('Original Image', image)
# cv2.imshow('Canny Edges', edges)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

##############################################################
# import cv2

# # 读取原始图像和灰度图像
# original_image = cv2.imread('1111.png')
# gray_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)

# # 使用Canny边缘检测算法得到边缘图像
# edges = cv2.Canny(gray_image, 100, 200)  # 参数可根据需要调整

# # 创建一个与原始图像大小相同的三通道图像，用于叠加
# output_image = cv2.cvtColor(gray_image, cv2.COLOR_GRAY2BGR)

# # 将边缘图像叠加到输出图像中
# output_image[edges != 0] = [255, 255, 255]  # 边缘部分标记为红色

# # 显示结果图像

# cv2.imshow('Output Image', output_image)
# cv2.imwrite('output.jpg', output_image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
#########################################################################
import cv2

# 读取图像
image = cv2.imread('t3.jpg')

# 将图像转换为灰度图像
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 使用自适应阈值处理进行图像分割
_, thresholded = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# 查找图像中的轮廓
contours, _ = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 创建一个与原始图像大小相同的掩膜图像
mask = np.zeros(image.shape[:2], dtype=np.uint8)

# 绘制轮廓到掩膜图像上
cv2.drawContours(mask, contours, -1, (255), thickness=cv2.FILLED)

# 使用掩膜图像和原始图像进行位运算
result = cv2.bitwise_and(image, image, mask=mask)

# 显示结果图像
cv2.imshow('Result', result)
cv2.waitKey(0)
cv2.destroyAllWindows()