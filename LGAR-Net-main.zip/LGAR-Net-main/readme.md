Detection results.
